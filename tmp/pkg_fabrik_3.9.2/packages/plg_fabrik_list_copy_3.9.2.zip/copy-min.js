/*! Fabrik */

define(["jquery","fab/list-plugin"],function(n,i){return new Class({Extends:i,initialize:function(n){this.parent(n)}})});