<?php
defined('JPATH_BASE') or die;

$d = $displayData;
