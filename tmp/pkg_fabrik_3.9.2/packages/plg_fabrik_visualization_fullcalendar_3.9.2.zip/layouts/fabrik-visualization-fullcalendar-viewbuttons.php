<?php
defined('JPATH_BASE') or die;
?>
<span class="calEventButtonsID">
	<button data-task="deleteCalEvent" class="btn popupDelete" data-toggle="tooltip" title="">
		<i class="icon-trash" data-isicon="true"></i>
	</button>
	<button data-task="editCalEvent" class="btn popupEdit" data-toggle="tooltip" title="">
		<i class="icon-edit" data-isicon="true"></i>
	</button>
	<button data-task="viewCalEvent" class="btn popupView" data-toggle="tooltip" title="">
		<i class="icon-eye" data-isicon="true"></i>
	</button>
</span>