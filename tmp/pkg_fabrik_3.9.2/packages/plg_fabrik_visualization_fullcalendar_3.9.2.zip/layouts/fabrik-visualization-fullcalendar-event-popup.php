<?php
defined('JPATH_BASE') or die;
?>
<a
	id=""
	class="fabrikEvent label"
	href="#fabrikEvent_modal"
	data-toggle="modal"
	data-title=""
	data-body=""
	data-buttons=""
>
</a>