<?php
defined('JPATH_BASE') or die;

$d = $displayData;
?>

<div class="row-fluid" data-role="fabrik-rowopts" data-optsperrow="<?php echo $d->optsPerRow; ?>">
</div>
