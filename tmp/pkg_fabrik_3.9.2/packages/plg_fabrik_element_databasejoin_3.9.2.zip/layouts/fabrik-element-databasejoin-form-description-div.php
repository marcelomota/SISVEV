<?php
/**
 * @package     ${NAMESPACE}
 * @subpackage
 *
 * @copyright   A copyright
 * @license     A "Slug" license name e.g. GPL2
 */
defined('JPATH_BASE') or die;

$d = $displayData;
?>
<div style="display: none" class="notice description-0">
</div>